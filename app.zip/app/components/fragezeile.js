app.component("fragezeile", {
    templateUrl: "components/fragezeile.html",
    bindings: {
        radio1:"@?",
        radio2:"@?",
        radio3:"@?",
        radio4:"@?",
        radio5:"@?",
        frage:"@"
    }
});